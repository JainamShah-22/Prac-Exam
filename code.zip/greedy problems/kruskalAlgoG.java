public class kruskalAlgoG {
    
    
    
    public static void main(String[] args) {
        
    }
}
